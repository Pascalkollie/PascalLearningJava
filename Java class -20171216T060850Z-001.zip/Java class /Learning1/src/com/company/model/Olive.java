package com.company.model;

public abstract class Olive {

     private OliveName name =  OliveName.KALAMATA;
     private long color = 0x2E0854;
     private int oli = 0;

     public Olive(OliveName kalamata, OliveColor purple, int oil){

     }

     public Olive(OliveName name, long color, int oil){

          this.name = name;
          this.color =color;
          this.oli = oil;
     }
     public OliveName getName() {
          return name;
     }

     public void setName(OliveName name) {
          this.name = name;
     }

     public long getColor() {
          return color;
     }

     public void setColor(long color) {
          this.color = color;
     }

     public int getOli() {
          return oli;
     }

     public void setOli(int oli) {
          this.oli = oli;
     }

     public abstract  String getOrigin();
     @Override
     public String toString() {return name.toString(); }

     public  int cruh(){

          String msg = name + ":" + oli +  getOrigin()
                  +":" + oli + " units";
          System.out.println(msg);
          return oli;
     }
}


