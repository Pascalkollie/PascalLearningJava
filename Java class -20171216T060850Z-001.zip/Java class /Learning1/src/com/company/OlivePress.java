package com.company;

import com.company.model.Olive;

import java.util.List;

public class OlivePress implements  Press {
        private int currentOil;
     public int getOli (List<Olive> olives){

         int totalOil = currentOil;
         for(Olive o: olives){
             System.out.println(o.getName());
             totalOil += o.getOli();
         }
         return totalOil;
     }

    @Override
    public void setOil(int oli) {
        currentOil = oli;
    }
}
