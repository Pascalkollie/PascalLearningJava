package com.company;

import com.company.model.Kalamata;
import com.company.model.Ligurian;
import com.company.model.Olive;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Main {

    public static void main(String[] args) throws Exception {

        List<Olive> olives = new ArrayList<>();

        olives.add( new Kalamata());
        olives.add( new Kalamata());
        olives.add( new Ligurian());
        olives.add( new Ligurian());
        olives.add( new Ligurian());
        olives.add( new Ligurian());

         Press press = new OlivePress();
         press.setOil(5);
         int totalOil = press.getOli(olives);
         System.out.println("You got " + totalOil + " units of oil");

         /**
          * This is how to get a random number without using Math.Random
          */
        Random generator = new Random();
        int index = generator.nextInt(6);
        System.out.println("Random value:" + index);

         Olive o = olives.get(index);
/**
 *  This is how you switch values using switch in java 7 and up
 */
         switch (o.getName()){
             case KALAMATA:
                 System.out.println(" It's Greek!");
                 break;
             case LIGURIAN:
                 System.out.println("It's French!");
                 break;

                 default:
                     System.out.println("I don't know where it's from ");
                     break;
         }
    }
}
