package com.company;

import com.company.model.Olive;

import java.util.List;

public interface Press {

    public int getOli (List<Olive> olives);
    public void setOil(int oli);






}
