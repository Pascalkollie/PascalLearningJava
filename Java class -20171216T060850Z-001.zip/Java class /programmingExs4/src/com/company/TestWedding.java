package com.company;


import java.time.LocalDate;

public class TestWedding {


    public static void main(String args[]) {


                Person p1 = new Person("John","Lewis",LocalDate.of(1990,2,26));

                Person p2 = new Person("Nancy","Gill", LocalDate.of(1990,5,28));

                Couple couple = new Couple("LoveBirds",p1,p2);

                Wedding w1 = new Wedding(LocalDate.of(2017,12,25),"NewYork",couple.getCoupleName());

                Wedding w2 = new Wedding(LocalDate.of(2017,12,26),"Toronto",couple.getCoupleName());

                System.out.println("--A couple arranged two events of their Wedding at 2 places---");

                System.out.println("Couple name : "+w1.getCoupleName());

                System.out.println("Person 1 : "+couple.getPerson1().getFirstName()+""+couple.getPerson1().getLastName());

                System.out.println("Person 2 : "+ couple.getPerson2().getFirstName()+""+couple.getPerson2().getLastName());

                System.out.println(" Event 1 : "+w1.getLocation()+" "+w1.getWeddingDate());

                System.out.println(" Event 2 : "+w2.getLocation()+" "+w2.getWeddingDate());

            }

            }


