package com.company;

import java.time.LocalDate;

public class DaysTilNextMonth {



     public static void main (String [] args){


           LocalDate currentDate = LocalDate.now();
          int dayOFMonth = currentDate.getDayOfMonth();

          int daysMonth = currentDate.lengthOfMonth();

          int lefDays = daysMonth - dayOFMonth;
         System.out.println("Current date:" + currentDate);

         System.out.println("Days left to next month" + ":" + lefDays);

         LocalDate nextMonth = currentDate.plusDays(lefDays + 1);

         System.out.println("Name of next month:" + nextMonth.getMonth());
     }

}
