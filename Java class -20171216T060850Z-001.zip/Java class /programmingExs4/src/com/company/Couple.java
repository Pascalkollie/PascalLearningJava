package com.company;

public class Couple {

    private String coupleName;

    public String getCoupleName() {

        return coupleName;

    }

    public void setCoupleName(String coupleName) {

        this.coupleName = coupleName;

    }

    private Person person1;

    private Person person2;

    public Person getPerson1() {

        return person1;

    }

    public void setPerson1(Person person1) {

        this.person1 = person1;

    }

    public Person getPerson2() {

        return person2;

    }

    public void setPerson2(Person person2) {

        this.person2 = person2;


    }

    public Couple(String coupleName, Person person1, Person person2) {

        super();

        this.coupleName = coupleName;

        this.person1 = person1;

        this.person2 = person2;

    }

}