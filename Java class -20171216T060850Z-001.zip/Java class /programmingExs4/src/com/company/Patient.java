package com.company;

public class Patient {




    private int pID;

    private int pAge;

    private BloodData pBloodData;

    public Patient()

    {

        pID= 0;

        pAge = 0;

        pBloodData = new BloodData("O", '+');

    }


    public Patient(int id1, int age1, String type1, char factor1)

    {

        pID = id1;

        pAge = age1;

        pBloodData = new BloodData(type1,factor1);

    }


    public int get_PatientID()

    {

        return pID;

    }

    public int get_PatientAge()

    {

        return pAge;

    }


    public String getPatient_BloodGroupType()

    {

        return pBloodData.getBloodGroupType();

    }

              /* GET PATIENT BloodData Rh Factor */

    public char getPatient_BloodGroupRhFactor()

    {

        return pBloodData.getBloodGroupRhFactor();

    }

}

