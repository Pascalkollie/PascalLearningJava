package com.company;


import java.time.LocalDate;

public class TestMonthHandling {

    public static void main (String [] args) {

        LocalDate jan31 = LocalDate.of(2015, 1, 13);
        LocalDate dec31 = LocalDate.of(2015, 12, 13);

        System.out.println("Current date:" + jan31);

        jan31 = jan31.plusMonths(1);
        System.out.println(jan31);

        System.out.println("After 3 month");
        jan31 = jan31.plusMonths(3);
        System.out.println(jan31);
        System.out.println("Current date:" + dec31);
        dec31 = dec31.plusMonths(1);
        System.out.println("After 1 month");
        System.out.println(dec31);
        dec31 = dec31.plusMonths(2);
        System.out.println("After 2 month");
        System.out.println(dec31);
        dec31 = dec31.plusMonths(3);
        System.out.println("After 3 month");
        System.out.println(dec31);


    }
}
