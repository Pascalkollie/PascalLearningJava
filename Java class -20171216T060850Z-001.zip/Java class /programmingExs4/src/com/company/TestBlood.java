package com.company;

public class TestBlood {

    public static void main(String[] args)

    {



        BloodData data1 = new BloodData();

        System.out.println("Blood GroupType: " + data1.getBloodGroupType());

        System.out.println("Blood GroupRH Factor: " + data1.getBloodGroupRhFactor());

        BloodData data2 = new BloodData();


        data2.setBloodGroupType("A");

        data2.setBloodGroupRhFactor('-');

        System.out.println();

        System.out.println("Blood Group Type: " + data2.getBloodGroupType());

        System.out.println("Blood Group RH Factor: " + data2.getBloodGroupRhFactor());

        System.out.println();

        BloodData data3 = new BloodData("A", '+');

        System.out.println("Blood Group Type: " + data3.getBloodGroupType());

        System.out.println("Blood GroupRH Factor: " + data3.getBloodGroupRhFactor());

    }

}

