package com.company;

public class TestParient {

    public static void main(String[] args)

    {


        Patient patient1 = new Patient(1,35,"B",'+');

        //DISPLAY PATIENT INFORMATION

        System.out.println("Patient Identification: " + patient1.get_PatientID());

        System.out.println("Patient Age: " + patient1.get_PatientAge());

        System.out.println("Blood Type: " + patient1.getPatient_BloodGroupType());

        System.out.println("RH Factor: " + patient1.getPatient_BloodGroupRhFactor());

    }
}
