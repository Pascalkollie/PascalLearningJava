package com.company;

import java.util.Scanner;

public class Circle {

    double Radius;
    double Diameter;
    double Area;

    Scanner scan = new Scanner(System.in);

    public Circle() {
        Radius = 1;
        Diameter = (Radius * 2);
        Area = Math.PI * (Radius * Radius);
    }

    public double getRadius() {
        return this.Radius;
    }

    public void setRadius(double Radius) {
        this.Radius = Radius;
        Diameter = (Radius * 2);
        Area = Math.PI * (Radius * Radius);
    }

}


