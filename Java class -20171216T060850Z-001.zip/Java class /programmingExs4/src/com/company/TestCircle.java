package com.company;

import javax.swing.*;
import java.util.Scanner;

public class TestCircle {

    double Radius;
    Scanner in = new Scanner(System.in);

    public static void main(String[] args) {

        // Create Circle Objects
        Circle Circle1 = new Circle();
        Circle Circle2 = new Circle();
        Circle Circle3 = new Circle();

        // Create output for user
        double r1=Double.parseDouble(JOptionPane.showInputDialog("Enter the radius of 1st circle: "));
        Circle1.setRadius(r1);
        System.out.println("Radius of 1st circle: "+Circle1.getRadius());
        r1=Double.parseDouble(JOptionPane.showInputDialog("Enter the radius of 1st circle: "));
        Circle2.setRadius(r1);
        System.out.println("Radius of 2nd circle: "+Circle2.getRadius());
        System.out.println("Radius of 3rd circle: Radius: "+Circle3.getRadius());

    }
}


