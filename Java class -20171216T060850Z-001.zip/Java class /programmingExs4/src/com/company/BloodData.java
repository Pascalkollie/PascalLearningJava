package com.company;

public class BloodData {

    private String blood_Type;

    private char rh_Factor;



    public BloodData()

    {

        blood_Type = "O";

        rh_Factor = '+';

    }


    public BloodData(String type1, char factor1)

    {

        blood_Type = type1;

        rh_Factor = factor1;

    }


    public void setBloodGroupType(String type1)

    {

        this.blood_Type = type1;

    }

    public void setBloodGroupRhFactor(char factor1)

    {
        this.rh_Factor = factor1;

    }

    public String getBloodGroupType()

    {
        return blood_Type;

    }

    public char getBloodGroupRhFactor()

    {

        return rh_Factor;

    }
}
