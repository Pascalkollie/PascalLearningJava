package com.company;

public class lengthOfMonth {


}
