package com.company;

public class Billing {

     public static void main (String[]args) {


         double photoPrice = 100;
         double quality = 10;
         double coupon = 10;


         System.out.println("Photo Price:" + photoPrice);
         System.out.println("Price with * % tax: " + computeBill(photoPrice));
         System.out.println();
         System.out.println("Photo Price:" + photoPrice);
         System.out.println("Quantity:" + quality);
         System.out.println("Price with 8 % tax:" + computeBill(photoPrice, quality))
         ;
         System.out.println();
         System.out.println("Photo price :" + photoPrice);
         System.out.println("Quantity:" + quality);
         System.out.println("Coupon:" + coupon);
         System.out.println("Price with 8 % tax:" + computeBill(photoPrice, coupon, quality));

     }
         private static double computeBill(Double photoPrice) {


             final double TAX = 8.08;
             return photoPrice *  photoPrice * TAX;
         }

        private static double computeBill(Double photoPrice, Double Quantity) {


        final double TAX = 8.08;
        return photoPrice * photoPrice * TAX;
           }
          private static double computeBill(double photoPrice, double quantity, double coupon){

          final double TAX = 0.08;
          return (photoPrice * quantity - coupon) + photoPrice * quantity * TAX;


     }
}
