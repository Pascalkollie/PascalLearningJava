package com.company;

import java.time.LocalDate;

public class Wedding {


    private LocalDate weddingDate;

    private String location;

    private String coupleName;

    public LocalDate getWeddingDate() {

        return weddingDate;

    }

    public void setWeddingDate(LocalDate weddingDate) {

        this.weddingDate = weddingDate;

    }

    public String getLocation() {

        return location;

    }

    public void setLocation(String location) {

        this.location = location;

    }

    public String getCoupleName() {

        return coupleName;

    }

    public void setCoupleName(String coupleName) {

        this.coupleName = coupleName;

    }

    public Wedding(LocalDate weddingDate, String location, String coupleName) {

        super();

        this.weddingDate = weddingDate;

        this.location = location;

        this.coupleName = coupleName;

    }

}


