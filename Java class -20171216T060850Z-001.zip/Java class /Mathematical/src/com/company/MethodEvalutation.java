package com.company;

public class MethodEvalutation {

     public static void main (String [] args){

         System.out.println("a " + Math.sqrt(4));
         System.out.println("b " + Math.sin(2 * Math.PI));
         System.out.println("c " + Math.cos(2 * Math.PI));
         System.out.println("d " + Math.pow(2, 2));
         System.out.println("e " + Math.log(Math.E));
         System.out.println("f " + Math.exp(1));
         System.out.println("g " + Math.max(2, Math.min(3, 4)));


     }
}
