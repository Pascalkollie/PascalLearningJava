package com.company;

public class Female extends People {

}
