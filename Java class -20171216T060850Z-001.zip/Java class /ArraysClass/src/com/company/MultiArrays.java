package com.company;

public class MultiArrays {

     public static void main (String [] args){

     }
}
