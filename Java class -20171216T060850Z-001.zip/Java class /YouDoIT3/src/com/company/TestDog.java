package com.company;

public class TestDog {

    public static void main(String [] args){

        ogTriathlonParticipant dog1 =
                new ogTriathlonParticipant("Bowser", 2, 85, 89, 0);
        dog1.display();
                ogTriathlonParticipant dog2 =
                new ogTriathlonParticipant("Rush", 3, 78, 72, 80);
        dog1.display();

                  ogTriathlonParticipant dog3 =
                new ogTriathlonParticipant("Ginger", 3, 90, 86, 72);
        dog3.display();
    }
}
