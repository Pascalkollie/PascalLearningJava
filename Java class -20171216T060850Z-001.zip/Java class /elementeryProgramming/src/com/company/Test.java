package com.company;

public class  Test {

     public static void main (String[]args){

          // Exponent Operations
         System.out.println(Math.pow(2, 3)); // Display 8.0
         System.out.println(Math.pow(4, 0.5)); // Display 2.0
         System.out.println(Math.pow(2.5, 2));  // Display 6.25
         System.out.println(Math.pow(2.5, -2)); // Display 0.16


     }
}

