package com.company;

public class ShowCurrentTime {

     public static void main (String[] args){
         // Obtain the total milesseconds since midnight, jan 1 , 1970

          long totalMilliseconds = System.currentTimeMillis();

          // Obtain the total seconds since midnight, Jan 1, 1920

         long totalSeconds = totalMilliseconds / 1000;

         // Compute the current seconds in the minute in the hour

         long currentSeconds = totalSeconds % 60;
         // obtain total hours

         long totalMinutes = totalSeconds / 60;

         // Compute the current minutes in the hour
         long CurrentMinutes = totalMinutes % 60;

         // Obtain total hour
         long totalHours = totalMinutes % 60;

         long currentHour = totalHours % 24;

         // Display result
         System.out.println( " Current time is " + currentSeconds  + ":" + currentSeconds + ":" + currentSeconds + " GMT");
     }
}
