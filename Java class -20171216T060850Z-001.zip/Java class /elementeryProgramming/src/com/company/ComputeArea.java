package com.company;

public class ComputeArea {
    public static void main(String[]args){
        double radius = 20; //Declare radius assign 20
        double area;  // Declare area

        //compute area
        area = radius * radius * 3.14159;

        //Display results
        System.out.println("The area for the circle of radius " + radius + " is " + area);


    }
}