package com.company;

import java.util.Scanner;

public class ComputeLone {
    public static void main (String [] args){
        // Create a scanner

        Scanner input = new Scanner(System.in);

        // Enter annual interest rate in percentage, e.g., 7.25 %
        System.out.print("Enter annual interact rate, e.g., 7.25: ");
        double annualIntreastRate = input.nextDouble();

        // Obtain monthly interest rate

        double monthlyIntreastRate = annualIntreastRate / 1200;

        // Enter number of years
        System.out.println( " Enter number of years an integer, e.g., 5: ");
        int numberOfYears = input.nextInt();

        // Enter loan amount
        System.out.print("Enter lone amount, e.g., 1232232:  ");
        double loneAmount = input.nextDouble();

        // Calculate payment
        double monthlyPayment = loneAmount * monthlyIntreastRate / (1 - 1/ Math.pow(1 +
                monthlyIntreastRate, numberOfYears * 12));

        double totalPayment = monthlyPayment * numberOfYears * 12;

        // Display result

        System.out.println("The monthly payment is $" + (int)(monthlyPayment * 100) / 100.0);
        System.out.println("The total payment is $" + (int) (totalPayment * 100) / 100.0);
    }
}
