package com.company;

import java.util.Scanner;

public class ComputeAbdUbtreprateBIM {

     public static void main (String [] args){

         // Prompt the user to enter weight in pound
         Scanner input = new Scanner(System.in);

     }
}
