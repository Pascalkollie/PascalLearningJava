package com.company;

public class Main {


//        private static final String USERNAME = "pascal";
//        private static final String PASSWORD = "pascal";
//        private static final String CONN_STRING = "jdbc:mysql:" +
//                "//locanhost/explorecalifornia";

    public static void main(String[] args) {

    }
}
