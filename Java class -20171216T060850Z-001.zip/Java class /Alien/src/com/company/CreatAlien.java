package com.company;

public class CreatAlien {

     public static void main (String [] args){

         Jupiterian ester = new Jupiterian("Brow", "Esther", 4);
         System.out.println(ester.toString());
         Martian kyle = new Martian("Blick", "Kyle", 6);
         System.out.println(kyle.toString());
     }
}
