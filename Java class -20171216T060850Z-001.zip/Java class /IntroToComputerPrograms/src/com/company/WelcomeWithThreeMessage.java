package com.company;

public class WelcomeWithThreeMessage {

    public static void main (String [] args){

        System.out.println("Programming is fun!");
        System.out.println("Fundamentals fires");
        System.out.println("Problem Driven");
    }
}
