package com.company;

public class ComputingExpressions {

     public static void main (String[]args){

         System.out.println((10.5 + 2 * 3) / (45 - 3.5));



     }
}
