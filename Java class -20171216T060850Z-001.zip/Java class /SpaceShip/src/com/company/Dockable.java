package com.company;

public interface Dockable {

     public void
}


