package com.company;

public abstract class Shap {

     public void printData(){
         System.out.println("This is Pascal ");
     }
}
