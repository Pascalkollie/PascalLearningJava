package com.company;

public class SandWich {

        String main_ingre;
        String bread_type;
        double price;
        public String getMain_ingre() {
            return main_ingre;
        }
        public void setMain_ingre(String main_ingre) {
            this.main_ingre = main_ingre;
        }
        public String getBread_type() {
            return bread_type;
        }
        public void setBread_type(String bread_type) {
            this.bread_type = bread_type;
        }
        public double getPrice() {
            return price;
        }
        public void setPrice(double price) {
            this.price = price;
        }

    }
