package com.company;

import java.util.Arrays;

public class ArrayMethodDemo {

    /**
     * Create an application containing an array that stores 10 integers. The application
     * should call five methods that in turn (1) display all the integers, (2) display all the
     * integers in reverse order, (3) display the sum of the integers, (4) display all values less
     * than a limiting argument, and (5) display all values that are higher than the calculated
     * average value. Save the file as ArrayMethodDemo.java.
     */


      public static void display(int[] array){

          for ( int n: array) {
              System.out.print (n + " ");

          }
      }
       public static void reverseOrder( int[] reverse) {
           int count = reverse.length;
           for (int i = count - 1; i >= 0; i--) {
               System.out.print(reverse[i] + " ");
           }
       }
           public static void sumOfIntegers(int[] sum){

                     int count = sum.length;
                     int add = 0;
                     for(int i = count - 1; i >= 0; i--)
                         add = add + sum[i];
                       System.out.println("The sum is " + add);
                }

                public static void lessValue ( int [] limit, int limits){
                   int values = limit.length;
                   for(int i = 0; i < values; i++){
                       if (limit[i] <  limits){
                           System.out.print(limit[i] + " "); } } }

                           public  static void averageHigher(int[] values){
                              int length = values.length;
                               int total = 0;
                               for (int i = length - 1 ; i >= 0 ; i--)

                                    total = total + values[i];
                                    double avg = total * 1.5 / length;

                                   for (int j = 0; j <length ; j++) {
                                       if (values[j] > avg) {
                                           System.out.print(values[j] + " ");
                                       }

                                   }
                               }
            public static void main (String [] args) {

           int[] arrays = {1,2,3,4,5,6,7,8,9,10};
           display(arrays);
           System.out.println();
           reverseOrder(arrays);
           System.out.println();
           sumOfIntegers(arrays);
           System.out.println("limit to 6");
           lessValue(arrays, 6);
           System.out.println("\n" + "Higher Average ");
           averageHigher(arrays);
           System.out.println();
       }

 }