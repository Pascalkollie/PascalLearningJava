package com.company;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class newOne {

       public static void main (String [] arg) {


              int [] num = {8,7,6,5,4,3,2,1,};
              Arrays.sort(num);

           for (int n: num
                ) {
               System.out.println(n);


           }
           ArrayList aList = new ArrayList();

           aList.add("1");
           aList.add("2");
           aList.add("3");
           aList.add("4");
           aList.add("5");

           System.out.println("Array list " + aList);
           Collections.reverse(aList);
           System.out.println("After Reverse Order, ArrayList Contains : " + aList);
           }


       }

