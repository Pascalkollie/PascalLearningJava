package com.company;


import java.util.Arrays;

public class ArrayLi {

    public static void main(String[] args) {

        System.out.println("Array of primitives ");
        int[] ints = {9, 6, 3};
        Arrays.sort(ints);
        for (int i = 0; i < ints.length; i++) {
            System.out.println(ints[i]);
        }

        System.out.println("Array of strings ");
        String[] colors = {"orange", "blue", "Green", "Black"};
        Arrays.sort(colors);
        for (int i = 0; i < colors.length; i++) {
            System.out.println(colors[i]);
        }

        System.out.println("Setting an initial size");
        int[] sized = new int[10];
        for (int i = 0; i < sized.length; i++) {
            sized[i] = i * 100;
        }
        for (int value : sized
                ) {
            System.out.println(value);
         }
                   System.out.println( " copy array ");
                   int [] copyed = new int [10];
                  System.arraycopy(sized, 1, copyed, 0, 4);
                      for (int value: copyed){
                     System.out.println(value);
                 }
        }
    }
