package com.company;

public class Arrays {



             public static void main (String[]args) {


                 String[][] name = new String[3][2];
                 name[0][0] = "Pascal";
                 name[0][1] = "Kollie";
                 name[1][0] = "Thomas";
                 name[1][1] = "Chalamo";
                 name[2][0] = "kato";
                 name[2][1] = "byan";




                 for (int i = 0; i < name.length; i++) {

                     String out = "";
                     for (int j = 0; j < name[i].length; j++) {

                         out += name[i][j] + " ";

                     }
                     System.out.println(out);
                 }
                  }
                 }


