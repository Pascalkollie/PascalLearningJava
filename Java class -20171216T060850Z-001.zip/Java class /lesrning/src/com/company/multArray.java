package com.company;

import java.util.Scanner;

public class multArray {


    public static void main(String[] args) {

        String[][] african = new String[3][2];

        Scanner sc = new Scanner(System.in);


        african[0][0] = "A";
        african[0][1] = "b";
        african[1][0] = "c";
        african[1][1] = "d";



     for (int i = 0; i < african.length;i++)
     {
         String name = "";
         for (int j = 0; j < african[i].length; j++)
         {
             name += african[i][j] + " ";
         }

         name += "\n";
         System.out.println(name);

        }
    }
}
