package com.company;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Lc3 {

     public static void main (String [] args){

         Scanner sc = new Scanner(System.in);

         List<String> name = new ArrayList<>();
         name.add("lee");

         System.out.println("Enter name");
         name.add(sc.nextLine());
         System.out.println(name);

//         String name2  = sc.nextLine();
//         Double d1 = Double.parseDouble(name2);

          int [] numberPeople =  {9, 4, 3, 6, 7,};
         Arrays.sort(numberPeople);
         for (int n: numberPeople
              ) {
             System.out.println(n);




         }

         }

}
