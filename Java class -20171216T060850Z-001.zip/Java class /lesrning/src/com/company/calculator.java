package com.company;

import com.company.utilities.MathHelper;

import java.util.Scanner;

public class calculator {

    public static void main(String[] args) {
        calculator cal = new calculator();
        cal.Calculate();

    }

    private void Calculate() {
        InputHelper helper = new InputHelper();
        System.out.println("Calculate numbers");
        String s1 = helper.getInput("");
        String numOp = helper.getInput(" + - * /");
        String s2 = helper.getInput("");


        double answer =  0;


        try {

            switch (numOp) {

                case "+":

                    answer = MathHelper.addNumber(s1, s2);
                    break;
                case "-":
                    answer = MathHelper.Substract(s1, s2);
                    break;

                case "*":
                    answer = MathHelper.Multipy(s1, s2);
                    break;
                case "/":
                    answer = MathHelper.dev(s1, s2);
                    break;

                default:
                    System.out.println("Wrong operation");
                    return;
            }
            System.out.println(answer);

        } catch (Exception e) {
            System.out.println("Exception" + e.getMessage());
        }
        }

          class InputHelper{
        public String getInput (String prompt){
            System.out.println(prompt);
            Scanner sc = new Scanner(System.in);
            return sc.nextLine();
        }
    }
}

