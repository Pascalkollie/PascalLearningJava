package com.company;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayTest

{

     public static void main (String [] args) {

         System.out.println("number array " + number());

         System.out.println(number());
             
         }

         public static List<Integer> number(){
         List<Integer>  num = new ArrayList<>(); 
         num.add(1);
         num.add(2);
         num.add(3);
         num.add(4);
         Collections.reverse(num);
         return num;
     }

}
