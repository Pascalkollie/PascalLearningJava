package com.company;


import java.util.HashMap;
import java.util.Map;

public class hasMap {

     public static void main (String [] args){

   Map<String, String> location = new HashMap<>();
           location.put("liberia ", "Monrovia");
           location.put("Georgia", "Atlanta");
           location.put("Guinea", "Pascal");

         System.out.println(location);

          location.put("Thomas", "christ");
         System.out.println(location);

          String loc = location.get("liberia");
         System.out.println("The capital of liberia is " + loc);

         location.remove("liberia");
         System.out.println(location);



     }
}
