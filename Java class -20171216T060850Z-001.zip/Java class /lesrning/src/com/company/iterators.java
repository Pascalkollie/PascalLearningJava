package com.company;

import java.util.*;

public class iterators {

     public static void main (String [] args) {

         System.out.println("Ordered data ");
         List<String> list = new ArrayList<>();
         list.add("Atlanta");
         list.add("Georgia");
         list.add("Guinea");
         System.out.println("toString () output");
         System.out.println(list);
         System.out.println("");

         System.out.println("Array iterator");
         Iterator<String> iterator = list.iterator();
         while (iterator.hasNext()) {
             String value = iterator.next();
             System.out.println(value);
         }

         System.out.println("ArrayList of ForEach");
         for (String value : list) {
             System.out.println(value);
         }
         System.out.println("Java 8 method reference");
         list.forEach(System.out::println);

         System.out.println(" un order data  ");
         HashMap<String, String> map = new HashMap<>();
         map.put("Atlanta", "Georgia");
         map.put("Florida", "Pascal");
         map.put("Guinea", "Kollie");

         System.out.println(map);
         System.out.println(" ");


         System.out.println("Hash map iterators");

         Set<String> keys = map.keySet();
         Iterator<String> iterator1 = keys.iterator();
         while (iterator1.hasNext()) ;{
             String key = iterator1.next();
             System.out.println("The capital of " + key + "is" + map.get(key));
         }
             System.out.println("HaschMap for each ");
             for (String key : keys) {
             System.out.println("The capital of " + key + "is" + map.get(key));
         }

     }
}