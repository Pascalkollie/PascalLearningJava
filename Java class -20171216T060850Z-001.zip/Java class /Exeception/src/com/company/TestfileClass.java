package com.company;

public class TestfileClass {

    public static void main (String [] args){
        // Create a file
        java.io.File file  = new java.io.File("image/us.gif");
        // Does the file exist
        System.out.println("Does it exist?" + file.exists());
        // The length of the file
        System.out.println("The file has " + file.length() + " bites ");
        // Can you read the file
        System.out.println("Can it be read?" + file.canRead());
        // Can Write the file
        System.out.println("Can it be written?" + file.canWrite());
        // Where is the path
        System.out.println("Is it directory?" + file.isDirectory());
        // Is this a file
        System.out.println("Is it a file? " + file.isFile());
        // What is the absolute location
        System.out.println("Is it absolute? " + file.isAbsolute());
        // Do you have access to this file
        System.out.println("Is it hidden? " + file.isHidden());
        // Is this the full location of the file
        System.out.println("Absolute path is " +
                file.getAbsolutePath());
        // Get the modified date
        System.out.println("Last modified on " + new java.util.Date(file.lastModified()));
    }
}
