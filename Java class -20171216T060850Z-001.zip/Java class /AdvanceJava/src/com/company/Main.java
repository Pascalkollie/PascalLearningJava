package com.company;



import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);



         List<Integer> values = new ArrayList<>();
          values.add(setValues());
          System.out.println("The total values" + values);
        System.out.println("The average is"  + total(values) );

    }

          public static int  setValues(){



           int number = 0;
              int total = number;
           Scanner sc = new Scanner(System.in);
           for (int i = 0; i < 5 ; ++i) {
               System.out.println("Enter number ");
               number = sc.nextInt();

            }
            return total;
            }
            
             public static List<Integer> total (List<Integer> values){

                 return  values;
            }

       }

